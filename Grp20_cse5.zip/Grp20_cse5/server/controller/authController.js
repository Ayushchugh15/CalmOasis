const User = require('../model/user.js');
const bcrypt = require('bcryptjs');

const registerUser = async (req, res) => {
  const { email, password,username } = req.body;
    console.log(email," ",password);
  try {
    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: 'User already exists' });
    }

    const user = new User({ email, password });
    await user.save();

    res.status(201).json({
      message: 'User registered successfully',
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

const loginUser = async (req, res) => {
  const { email, password } = req.body;

  console.log(email," ",password);
//   try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ error: 'Invalid credentials (email)' });
    }
    console.log(user);
    const isMatch = await user.matchPassword(password);
    console.log(isMatch);
    if (!isMatch) {
      return res.status(400).json({ error: 'Invalid credentials (password)' });
    }

    res.json({
      message: 'User logged in successfully',
    });
//   } catch (error) {
//     res.status(500).json({ message: 'Server error', error: error.message });
//   }
};

module.exports = {
  registerUser,
  loginUser,
};
