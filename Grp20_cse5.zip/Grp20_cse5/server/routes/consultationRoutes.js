const express = require('express');
const router = express.Router();
const Consultation = require('../model/Consultation.js');

// Route to handle consultation form submission
router.post('/submit', async (req, res) => {
  const { name, email, date, time, message } = req.body;

  console.log("Data received",req.body);
  

  try {
    const newConsultation = new Consultation({ name, email, date, time, message });
    await newConsultation.save();
    res.status(200).json({ message: 'Consultation request saved successfully!' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to save consultation request.' });
  }
});

module.exports = router;
