// Set up the document title
document.title = "Calm Oasis";

// Apply the styles dynamically
const style = document.createElement('style');
style.textContent = `
    body {
        font-family: Arial, sans-serif;
        background-color: #E8F0F2;
        color: #2F4F4F;
        text-align: center;
        margin: 0;
        padding: 0;
    }
    .navbar {
        background-color: #3aafa9;
        overflow: hidden;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 20px;
        font-family: 'Roboto', sans-serif;
    }
    .navbar a {
        display: block;
        color: white;
        text-align: center;
        padding: 14px 20px;
        text-decoration: none;
        font-size: 17px;
    }
    .navbar a:hover {
        background-color: #2e8b8a;
        color: white;
    }
    .navbar .site-name {
        font-size: 20px;
        font-weight: bold;
    }
    .header {
        padding: 50px 0;
    }
    .header h1 {
        font-size: 48px;
        color: #3aafa9;
        margin: 0;
    }
    .header p {
        font-size: 20px;
        color: #3aafa9;
        margin: 10px 0 20px;
    }
    .header .explore-button {
        background-color: #3aafa9;
        color: white;
        border: none;
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        border-radius: 5px;
        text-decoration: none;
    }
    .header .explore-button:hover {
        background-color: #2e8b8a;
    }
    .featured-courses {
        padding: 50px 0;
    }
    .featured-courses h2 {
        font-size: 36px;
        color: #4682B4;
        margin-bottom: 40px;
    }
    .courses {
        display: flex;
        justify-content: center;
        gap: 20px;
        flex-wrap: wrap;
    }
    .course {
        background-color: #F0FFF0;
        border-radius: 10px;
        padding: 20px;
        width: 300px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
        cursor: pointer;
        transition: transform 0.3s ease;
    }
    .course:hover {
        transform: scale(1.05);
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
    }
    .about, .testimonials {
        padding: 50px 20px;
        background-color: #F5F5F5;
    }
    .testimonial {
        display: none;
    }
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        justify-content: center;
        align-items: center;
    }
    .modal-content {
        background: white;
        padding: 20px;
        border-radius: 10px;
        width: 80%;
        max-width: 400px;
        text-align: left;
    }
    .close-modal {
        background: #3aafa9;
        color: white;
        border: none;
        padding: 10px;
        cursor: pointer;
        margin-top: 10px;
    }
`;
document.head.appendChild(style);

// Navbar creation with links
const navbar = document.createElement('div');
navbar.classList.add('navbar');

const siteName = document.createElement('div');
siteName.classList.add('site-name');
siteName.textContent = 'Calm Oasis';
navbar.appendChild(siteName);

const navLinks = [
    { text: 'Home', href: 'index.html' },
    { text: 'Soothing Audios', href: 'audios.html' },
    { text: 'Meditation Courses', href: 'courses.html' },
    { text: 'Blog', href: 'blog.html' },
    { text: 'Login/Signup', href: 'signup.html' }
];

navLinks.forEach(link => {
    const a = document.createElement('a');
    a.href = link.href;
    a.textContent = link.text;
    navbar.appendChild(a);
});

document.body.appendChild(navbar);

// Header section
const header = document.createElement('div');
header.classList.add('header');

const headerTitle = document.createElement('h1');
headerTitle.textContent = 'Welcome to Calm Oasis';
header.appendChild(headerTitle);

const headerText = document.createElement('p');
headerText.textContent = 'Your sanctuary for mental well-being and mindfulness.';
header.appendChild(headerText);

const exploreButton = document.createElement('a');
exploreButton.classList.add('explore-button');
exploreButton.href = 'courses.html';
exploreButton.textContent = 'Explore Courses';
header.appendChild(exploreButton);

document.body.appendChild(header);

// Featured Courses Section with modal for course details
const featuredCourses = document.createElement('div');
featuredCourses.classList.add('featured-courses');

const coursesTitle = document.createElement('h2');
coursesTitle.textContent = 'Featured Meditation Courses';
featuredCourses.appendChild(coursesTitle);

const coursesContainer = document.createElement('div');
coursesContainer.classList.add('courses');

// Courses data
const coursesData = [
    {
        title: 'Mindfulness Meditation',
        description: 'Learn to cultivate mindfulness through guided sessions.',
        imgSrc: 'https://storage.googleapis.com/a1aa/image/ZubUeuLBHc01N6cxHnpwZieKBHEdIeeTLQJ7fMUEBhEp3lWcC.jpg'
    },
    {
        title: 'Stress Relief Techniques',
        description: 'Master techniques to relieve stress and promote relaxation.',
        imgSrc: 'https://storage.googleapis.com/a1aa/image/71xcf2nm0XzfMUxR8iQhpR4fjlc8f6I5uuCf7QJAfT9lRMt4E.jpg'
    },
    {
        title: 'Guided Visualization',
        description: 'Explore the power of visualization to enhance your meditation.',
        imgSrc: 'https://storage.googleapis.com/a1aa/image/w35xEpZHTu5ABZHME62pSFeAfCaGfQGwtW69wiucye94STLOB.jpg'
    }
];

coursesData.forEach(course => {
    const courseDiv = document.createElement('div');
    courseDiv.classList.add('course');

    const img = document.createElement('img');
    img.src = course.imgSrc;
    img.alt = course.title;
    img.width = 50;
    img.height = 50;
    courseDiv.appendChild(img);

    const courseTitle = document.createElement('h3');
    courseTitle.textContent = course.title;
    courseDiv.appendChild(courseTitle);

    const courseDescription = document.createElement('p');
    courseDescription.textContent = course.description;
    courseDiv.appendChild(courseDescription);

    coursesContainer.appendChild(courseDiv);
});

featuredCourses.appendChild(coursesContainer);
document.body.appendChild(featuredCourses);

// Modal for course details
const modal = document.createElement('div');
modal.classList.add('modal');
document.body.appendChild(modal);

coursesContainer.addEventListener('click', (event) => {
    if (event.target.closest('.course')) {
        const course = event.target.closest('.course');
        modal.innerHTML = `
            <div class="modal-content">
                <h2>${course.querySelector('h3').textContent}</h2>
                <p>${course.querySelector('p').textContent}</p>
                <button class="close-modal">Close</button>
            </div>
        `;
        modal.style.display = 'flex';
    }
});

modal.addEventListener('click', (event) => {
    if (event.target.classList.contains('close-modal') || event.target === modal) {
        modal.style.display = 'none';
    }
});

// About Section
const aboutSection = document.createElement('div');
aboutSection.classList.add('about');

const aboutTitle = document.createElement('h2');
aboutTitle.textContent = 'About Calm Oasis';
aboutSection.appendChild(aboutTitle);

const aboutText = document.createElement('p');
aboutText.textContent = 'Calm Oasis is dedicated to providing a peaceful and supportive environment for individuals seeking to improve their mental well-being and mindfulness.';
aboutSection.appendChild(aboutText);

document.body.appendChild(aboutSection);

// Testimonials Section with carousel
const testimonials = document.createElement('div');
testimonials.classList.add('testimonials');

const testimonialsTitle = document.createElement('h2');
testimonialsTitle.textContent = 'What Our Participants Say';
testimonials.appendChild(testimonialsTitle);

const testimonialsData = [
    { text: "Calm Oasis has transformed my life.", author: "Aditya" },
    { text: "The stress relief techniques have been invaluable.", author: "Ridham" },
    { text: "I've learned so much about mindfulness.", author: "Sakshi" }
];

testimonialsData.forEach((testimonialData, index) => {
    const testimonial = document.createElement('div');
    testimonial.classList.add('testimonial');
    if (index === 0) testimonial.style.display = 'block';

    const text = document.createElement('p');
    text.textContent = testimonialData.text;
    testimonial.appendChild(text);

    const author = document.createElement('p');
    author.textContent = `- ${testimonialData.author}`;
    testimonial.appendChild(author);

    testimonials.appendChild(testimonial);
});

document.body.appendChild(testimonials);

// Testimonial Carousel
let currentTestimonial = 0;
const testimonialElements = document.querySelectorAll('.testimonial');

function showTestimonial(index) {
    testimonialElements.forEach((testimonial, i) => {
        testimonial.style.display = i === index ? 'block' : 'none';
    });
}

setInterval(() => {
    currentTestimonial = (currentTestimonial + 1) % testimonialElements.length;
    showTestimonial(currentTestimonial);
}, 3000); // change every 3 seconds
