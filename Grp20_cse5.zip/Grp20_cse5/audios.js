// Header
const headerContent = `
    <div class="header-container">
        <div class="logo">Calm Oasis</div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="courses.html">Meditation Courses</a></li>
                <li><a href="audios.html">Soothing Audios</a></li>
                <li><a href="blog.html">Blog</a></li>
                <li><a href="login.html">Login/Signup</a></li>
            </ul>
        </nav>
    </div>
`;
document.getElementById('header').innerHTML = headerContent;

// Soothing Audios Page Content
const audiosContent = `
    <h1>Soothing Meditation Audios</h1>
    <p>Listen to our carefully curated selection of calming audios to help you relax, sleep, and find inner peace.</p>
    <div class="audio-list">
        <div class="audio-item">
            <h3>Relaxation - Calm and Peaceful Music</h3>
            <iframe src="https://www.youtube.com/embed/2OEL4P1Rz04" title="Relaxation - Calm and Peaceful Music"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen></iframe>
        </div>
        <div class="audio-item">
            <h3>Sleep - Deep Sleep Music</h3>
            <iframe src="https://www.youtube.com/embed/1ZYbU82GVz4" title="Sleep - Deep Sleep Music"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen></iframe>
        </div>
        <div class="audio-item">
            <h3>Focus - Study and Concentration Music</h3>
            <iframe src="https://www.youtube.com/embed/5qap5aO4i9A" title="Focus - Study and Concentration Music"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen></iframe>
        </div>
    </div>
`;
document.getElementById('audios').innerHTML = audiosContent;

// Footer
const footerContent = `
    <div class="footer-container">
        <p>&copy; 2024 Calm Oasis. All Rights Reserved.</p>
        <div class="social-icons">
            <a href="#">Facebook</a> | <a href="#">Twitter</a> | <a href="#">Instagram</a>
        </div>
    </div>
`;
document.getElementById('footer').innerHTML = footerContent;


fetch('audios_data.json')
    .then(response => response.json())
    .then(data => {
        // Set the page title
        document.title = data.pageTitle;

        // Select the container where audio items will be displayed
        const audiosContainer = document.getElementById('audios-container');
        audiosContainer.innerHTML = ''; // Clear existing content

        // Populate the audios section
        data.audios.forEach(audio => {
            // Create a container for each audio track
            const audioDiv = document.createElement('div');
            audioDiv.className = 'audio-track';

            // Create and add the title
            const title = document.createElement('h2');
            title.textContent = audio.title;
            audioDiv.appendChild(title);

            // Create and add the description
            const description = document.createElement('p');
            description.textContent = audio.description;
            audioDiv.appendChild(description);

            // Create and add the audio player
            const audioPlayer = document.createElement('audio');
            audioPlayer.controls = true;
            audioPlayer.src = audio.audioSrc;
            audioDiv.appendChild(audioPlayer);

            // Append the audio track container to the main container
            audiosContainer.appendChild(audioDiv);
        });
    })
    .catch(error => console.error('Error loading audio JSON:', error));
