

// Get the button by ID
const button = document.getElementById('submit');

// Add event listener to the button
button.addEventListener("click", async function (event) {
    event.preventDefault();
  
    const consultationForm = document.querySelector('.consultation-form');
  
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const date = document.getElementById('date').value;
    const time = document.getElementById('time').value;
    const message = document.getElementById('message').value;
  
    try {
      const response = await fetch('http://localhost:5000/api/consultation/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, date, time, message }),
      });
  
      if (response.ok) {
        alert("Your consultation request has been submitted successfully!");
        consultationForm.reset();
      } else {
        alert("Failed to submit your consultation request.");
      }
    } catch (error) {
      console.error('Error submitting the form:', error);
      alert("An error occurred while submitting the form.");
    }
  });
  
