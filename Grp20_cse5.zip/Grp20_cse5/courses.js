// Function to generate header
function generateHeader() {
    return `
        <div class="header-container">
            <div class="logo">Calm Oasis</div>
            <nav>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="courses.html">Meditation Courses</a></li>
                    <li><a href="audios.html">Soothing Audios</a></li>
                    <li><a href="blog.html">Blog</a></li>
                    <li><a href="login.html">Login/Signup</a></li>
                </ul>
            </nav>
        </div>
    `;
}

// Course data array with price attribute added for sorting purposes
const coursesData = [
    { title: "Beginner Meditation", description: "A basic introduction to meditation techniques.", price: 2000 },
    { title: "Stress Relief Meditation", description: "Learn to reduce stress through mindfulness exercises.", price: 3000 },
    { title: "Advanced Mindfulness", description: "Deepen your practice with advanced meditation techniques.", price: 4500 },
];

// Function to generate courses content with search and sort controls
function generateCoursesContent() {
    return `
        <h1>Meditation Courses</h1>
        <div>
            <input type="text" id="search-bar" placeholder="Search courses..." oninput="filterCourses()" />
            <button onclick="sortCourses('alpha')">Sort by Alphabet</button>
            <button onclick="sortCourses('price')">Sort by Price</button>
        </div>
        <div class="course-list" id="course-list">
            ${coursesData.map(course => generateCourseHTML(course)).join('')}
        </div>
        <button onclick="window.location.href='consultation.html';">Book Video Consultation</button>
    `;
}

// Function to generate individual course HTML
function generateCourseHTML(course) {
    return `
        <div class="course-item" data-title="${course.title}" data-price="${course.price}">
            <h2>${course.title}</h2>
            <p>${course.description} Price: ₹${course.price}</p>
        </div>
    `;
}

// Function to filter courses based on search input
function filterCourses() {
    const searchQuery = document.getElementById('search-bar').value.toLowerCase();
    const courseItems = document.querySelectorAll('.course-item');
    
    courseItems.forEach(item => {
        const title = item.getAttribute('data-title').toLowerCase();
        const description = item.textContent.toLowerCase();
        if (title.includes(searchQuery) || description.includes(searchQuery)) {
            item.style.display = "block";
        } else {
            item.style.display = "none";
        }
    });
}

// Function to sort courses
function sortCourses(criteria) {
    const courseList = document.getElementById('course-list');
    const courseItems = Array.from(document.querySelectorAll('.course-item'));

    let sortedItems;
    if (criteria === 'alpha') {
        sortedItems = courseItems.sort((a, b) => 
            a.getAttribute('data-title').localeCompare(b.getAttribute('data-title'))
        );
    } else if (criteria === 'price') {
        sortedItems = courseItems.sort((a, b) => 
            parseFloat(a.getAttribute('data-price')) - parseFloat(b.getAttribute('data-price'))
        );
    }

    // Reorder the course items in the course list
    courseList.innerHTML = "";
    sortedItems.forEach(item => courseList.appendChild(item));
}

// Function to generate footer
function generateFooter() {
    return `
        <div class="footer-container">
            <p>&copy; 2024 Calm Oasis. All Rights Reserved.</p>
            <div class="social-icons">
                <a href="#">Facebook</a> | <a href="#">Twitter</a> | <a href="#">Instagram</a>
            </div>
        </div>
    `;
}

// Apply content to respective sections
document.getElementById('header').innerHTML = generateHeader();
document.getElementById('courses').innerHTML = generateCoursesContent();
document.getElementById('footer').innerHTML = generateFooter();


document.addEventListener("DOMContentLoaded", function () {
    const coursesContainer = document.getElementById("courses"); // Make sure there's a container with id "courses" in your HTML

    // Fetch JSON data
    fetch("courses.json") // Adjust path if needed
        .then(response => response.json())
        .then(data => {
            // Loop through each course and create HTML elements for it
            data.forEach(course => {
                const courseItem = document.createElement("div");
                courseItem.classList.add("course-item");

                courseItem.innerHTML = `
                    <h2>${course.title}</h2>
                    <p>${course.description}</p>
                    <p><strong>Price:</strong> ${course.price}</p>
                `;

                // Append each course item to the courses container
                coursesContainer.appendChild(courseItem);
            });
        })
        .catch(error => console.error("Error loading courses:", error));
});
